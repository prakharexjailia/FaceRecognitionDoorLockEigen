import cv2
import numpy as np
import sqlite3
import time

faceDetect = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

def insertOrUpdate(Id,Name,Age):
    conn = sqlite3.connect("SQLFace.db")
    data = (Id,Name,Age)
    cmd = "SELECT * FROM People WHERE ID="+str(Id)
    cursor = conn.execute(cmd)
    isRecordExist = 0
    for row in cursor:
        isRecordExist=1
    if(isRecordExist==1):
        cmd = "UPDATE People SET Name=?,Age=? WHERE ID=?"
        conn.execute(cmd,(Name,Age,Id))
    else:
        cmd = "INSERT INTO People Values(?,?,?)"
        conn.execute(cmd,data)
    conn.commit()
    conn.close()


id = raw_input("enter id : ")
name = str(raw_input("enter name : "))
age = raw_input("enter age : ")

insertOrUpdate(id,name,age)

cam = cv2.VideoCapture(0)

ret,img = cam.read()
print("wait 5 sec")
time.sleep(5)

smapleCount = 1

imageNo=0
try:
    while(True):
        ret,img = cam.read()
        gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
        faces = faceDetect.detectMultiScale(gray,1.3,5)
         
        for (x,y,w,h) in faces:
            imageNo=imageNo+1
            image = gray[y:y+h,x:x+w]
            resized = cv2.resize(image,(200,150))
            cv2.imwrite("database/User."+str(id)+"."+str(imageNo)+".jpg",resized)
            cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
            cv2.waitKey(100)
            
        cv2.imshow("faces",img)
        cv2.waitKey(1)
        if(imageNo>smapleCount):
            break
        if(cv2.waitKey(1)==ord('q')):
            break

finally:
    cam.release()
    cv2.destroyAllWindows()
            
